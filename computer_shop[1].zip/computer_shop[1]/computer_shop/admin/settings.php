<?php
$page_title = "Settings";
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../includes/header.php';
?>

<div class="container">
    <h1 style="color:#333; margin-bottom: 1rem;">Settings</h1>
    <div class="form-container" style="max-width:100%;">
        <p>This is a placeholder for global settings (e.g., site name, contact info, payment settings). Implement as needed.</p>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>