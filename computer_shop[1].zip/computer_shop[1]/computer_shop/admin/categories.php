<?php
$page_title = "Manage Categories";
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../includes/header.php';

function upload_image($fieldName, $oldFilename = null) {
    if (!isset($_FILES[$fieldName]) || $_FILES[$fieldName]['error'] === UPLOAD_ERR_NO_FILE) {
        return $oldFilename; // No new file uploaded
    }

    $file = $_FILES[$fieldName];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        throw new Exception('Image upload error.');
    }

    $allowed = ['jpg','jpeg','png','gif'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed, true)) {
        throw new Exception('Invalid image type. Allowed: jpg, jpeg, png, gif.');
    }

    if ($file['size'] > 5 * 1024 * 1024) { // 5MB
        throw new Exception('Image too large. Max 5MB.');
    }

    $newName = 'cat_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $destDir = __DIR__ . '/../upload/';
    if (!is_dir($destDir)) {
        mkdir($destDir, 0777, true);
    }
    $destPath = $destDir . $newName;

    if (!move_uploaded_file($file['tmp_name'], $destPath)) {
        throw new Exception('Failed to save image.');
    }

    // Delete old file if exists
    if ($oldFilename) {
        $oldPath = $destDir . $oldFilename;
        if (is_file($oldPath)) {
            @unlink($oldPath);
        }
    }

    return $newName;
}

$errors = [];
$success = '';

// Create/Update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $status = in_array(($_POST['status'] ?? 'active'), ['active','inactive'], true) ? $_POST['status'] : 'active';

    if ($name === '') {
        $errors[] = 'Name is required.';
    }

    if (empty($errors)) {
        try {
            if ($id > 0) {
                // Update existing
                // Get old image
                $stmt = $pdo->prepare("SELECT image FROM categories WHERE id = ?");
                $stmt->execute([$id]);
                $oldImg = $stmt->fetchColumn();

                $newImg = $oldImg;
                try {
                    $newImg = upload_image('image', $oldImg);
                } catch (Exception $e) {
                    if ($_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
                        throw $e; // only throw if an upload was attempted
                    }
                }

                $stmt = $pdo->prepare('UPDATE categories SET name=?, description=?, status=?, image=? WHERE id=?');
                $stmt->execute([$name, $description, $status, $newImg, $id]);
                $success = 'Category updated.';
            } else {
                // Create new
                $imgName = null;
                try {
                    $imgName = upload_image('image', null);
                } catch (Exception $e) {
                    // Image optional on create, continue without image if no file chosen
                    if (isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
                        throw $e; // if upload attempted and failed, surface error
                    }
                }

                $stmt = $pdo->prepare('INSERT INTO categories (name, description, status, image) VALUES (?, ?, ?, ?)');
                $stmt->execute([$name, $description, $status, $imgName]);
                $success = 'Category created.';
            }
        } catch (Exception $e) {
            $errors[] = 'Failed to save category.';
        }
    }
}

// Delete
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id']) && ctype_digit($_GET['id'])) {
    $id = (int)$_GET['id'];
    try {
        // Get current image
        $stmt = $pdo->prepare("SELECT image FROM categories WHERE id = ?");
        $stmt->execute([$id]);
        $img = $stmt->fetchColumn();

        $stmt = $pdo->prepare('DELETE FROM categories WHERE id = ?');
        $stmt->execute([$id]);

        if ($stmt->rowCount() > 0 && $img) {
            $path = __DIR__ . '/../upload/' . $img;
            if (is_file($path)) {
                @unlink($path);
            }
        }
        $success = 'Category deleted.';
    } catch (Exception $e) {
        $errors[] = 'Failed to delete category. Ensure no products are linked.';
    }
}

// Edit fetch
$editing = null;
if (isset($_GET['action']) && $_GET['action'] === 'edit' && isset($_GET['id']) && ctype_digit($_GET['id'])) {
    $id = (int)$_GET['id'];
    $stmt = $pdo->prepare('SELECT * FROM categories WHERE id = ?');
    $stmt->execute([$id]);
    $editing = $stmt->fetch();
}

// List
$categories = [];
try {
    $stmt = $pdo->query('SELECT * FROM categories ORDER BY created_at DESC');
    $categories = $stmt->fetchAll();
} catch (Exception $e) {
    $categories = [];
}
?>

<div class="container">
    <h1 style="color:#333; margin-bottom: 1rem;">Categories</h1>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-error"><?php foreach ($errors as $err): ?><div><?php echo htmlspecialchars($err); ?></div><?php endforeach; ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
        <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
    <?php endif; ?>

    <div class="form-container">
        <h2><?php echo $editing ? 'Edit Category' : 'Add New Category'; ?></h2>
        <form method="POST" enctype="multipart/form-data">
            <?php if ($editing): ?><input type="hidden" name="id" value="<?php echo (int)$editing['id']; ?>"><?php endif; ?>
            <div class="form-group">
                <label for="name">Name *</label>
                <input type="text" id="name" name="name" required value="<?php echo htmlspecialchars($editing['name'] ?? ''); ?>">
            </div>
            <div class="form-group">
                <label for="description">Description</label>
                <textarea id="description" name="description" rows="3"><?php echo htmlspecialchars($editing['description'] ?? ''); ?></textarea>
            </div>
            <div class="form-group">
                <label for="status">Status</label>
                <select id="status" name="status">
                    <option value="active" <?php echo $editing && $editing['status'] === 'active' ? 'selected' : ''; ?>>Active</option>
                    <option value="inactive" <?php echo $editing && $editing['status'] === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                </select>
            </div>
            <div class="form-group">
                <label for="image">Image <?php echo $editing && $editing['image'] ? '(upload to replace)' : ''; ?></label>
                <input type="file" id="image" name="image" accept="image/*">
                <?php if ($editing && $editing['image']): ?>
                    <div style="margin-top:0.5rem;">
                        <img src="/computer_shop/upload/<?php echo htmlspecialchars($editing['image']); ?>" alt="" style="width:120px; height:120px; object-fit:cover; border:1px solid #eee; border-radius:6px;">
                    </div>
                <?php endif; ?>
            </div>
            <button type="submit" class="btn-submit"><?php echo $editing ? 'Update' : 'Create'; ?></button>
            <?php if ($editing): ?><a href="/computer_shop/admin/categories.php" class="btn-register" style="margin-left:0.5rem;">Cancel</a><?php endif; ?>
        </form>
    </div>

    <div class="form-container" style="max-width:100%;">
        <?php if (empty($categories)): ?>
            <div class="alert alert-info">No categories found.</div>
        <?php else: ?>
            <div style="overflow-x:auto;">
                <table style="width:100%; border-collapse: collapse;">
                    <thead>
                        <tr>
                            <th style="text-align:left; padding:8px; border-bottom:1px solid #eee;">Image</th>
                            <th style="text-align:left; padding:8px; border-bottom:1px solid #eee;">Name</th>
                            <th style="text-align:left; padding:8px; border-bottom:1px solid #eee;">Description</th>
                            <th style="text-align:left; padding:8px; border-bottom:1px solid #eee;">Status</th>
                            <th style="text-align:left; padding:8px; border-bottom:1px solid #eee;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($categories as $cat): ?>
                            <tr>
                                <td style="padding:8px; border-bottom:1px solid #f5f5f5;">
                                    <?php if ($cat['image']): ?>
                                        <img src="/computer_shop/upload/<?php echo htmlspecialchars($cat['image']); ?>" alt="" style="width:50px; height:50px; object-fit:cover; border-radius:4px;">
                                    <?php else: ?>
                                        <span style="color:#aaa;">—</span>
                                    <?php endif; ?>
                                </td>
                                <td style="padding:8px; border-bottom:1px solid #f5f5f5;"><?php echo htmlspecialchars($cat['name']); ?></td>
                                <td style="padding:8px; border-bottom:1px solid #f5f5f5;"><?php echo htmlspecialchars($cat['description']); ?></td>
                                <td style="padding:8px; border-bottom:1px solid #f5f5f5; text-transform:capitalize;"><?php echo htmlspecialchars($cat['status']); ?></td>
                                <td style="padding:8px; border-bottom:1px solid #f5f5f5;">
                                    <a class="btn-register" href="/computer_shop/admin/categories.php?action=edit&id=<?php echo (int)$cat['id']; ?>">Edit</a>
                                    <a class="btn-logout" style="padding:0.4rem 0.8rem;" href="/computer_shop/admin/categories.php?action=delete&id=<?php echo (int)$cat['id']; ?>" onclick="return confirm('Delete this category?');">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>