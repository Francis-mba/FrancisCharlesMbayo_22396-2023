<?php
$page_title = "Admin Dashboard";
require_once __DIR__ . '/../includes/header.php';
requireAdmin();

$stats = [
    'users' => 0,
    'products' => 0,
    'orders' => 0,
    'sales' => 0.0,
    'categories' => 0,
];
$recent_orders = [];

try {
    // Total users
    $stats['users'] = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();

    // Total products
    $stats['products'] = (int)$pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();

    // Total orders
    $stats['orders'] = (int)$pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();

    // Total sales (delivered/processing/shipped)
    $stmt = $pdo->query("SELECT COALESCE(SUM(total_amount), 0) FROM orders WHERE status IN ('processing','shipped','delivered')");
    $stats['sales'] = (float)$stmt->fetchColumn();

    // Total categories
    $stats['categories'] = (int)$pdo->query("SELECT COUNT(*) FROM categories")->fetchColumn();

    // Recent orders
    $stmt = $pdo->query("SELECT o.id, o.total_amount, o.status, o.created_at, u.username, u.full_name
                         FROM orders o
                         JOIN users u ON o.user_id = u.id
                         ORDER BY o.created_at DESC
                         LIMIT 10");
    $recent_orders = $stmt->fetchAll();
} catch (Exception $e) {
    // Keep defaults
}
?>

<div class="container">
    <h1 style="color:#333; margin-bottom: 1rem;">Computer Shop Admin Dashboard</h1>

    <div class="products-grid" style="grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));">
        <div class="product-card">
            <div class="product-info">
                <h3>Total Users</h3>
                <div class="product-price" style="font-size:2rem;"><?php echo number_format($stats['users']); ?></div>
                <a href="/computer_shop/admin/users.php" class="btn-add-cart" style="display:inline-block; text-align:center;">Manage Users</a>
            </div>
        </div>
        <div class="product-card">
            <div class="product-info">
                <h3>Total Products</h3>
                <div class="product-price" style="font-size:2rem;"><?php echo number_format($stats['products']); ?></div>
                <a href="/computer_shop/admin/product.php" class="btn-add-cart" style="display:inline-block; text-align:center;">Manage Products</a>
            </div>
        </div>
        <div class="product-card">
            <div class="product-info">
                <h3>Total Orders</h3>
                <div class="product-price" style="font-size:2rem;"><?php echo number_format($stats['orders']); ?></div>
                <a href="/computer_shop/admin/order.php" class="btn-add-cart" style="display:inline-block; text-align:center;">Manage Orders</a>
            </div>
        </div>
        <div class="product-card">
            <div class="product-info">
                <h3>Total Sales</h3>
                <div class="product-price" style="font-size:2rem;">$<?php echo number_format($stats['sales'], 2); ?></div>
                <a href="/computer_shop/admin/dashboard.php" class="btn-add-cart" style="display:inline-block; text-align:center;">Refresh</a>
            </div>
        </div>
        <div class="product-card">
            <div class="product-info">
                <h3>Total Categories</h3>
                <div class="product-price" style="font-size:2rem;"><?php echo number_format($stats['categories']); ?></div>
                <a href="/computer_shop/admin/categories.php" class="btn-add-cart" style="display:inline-block; text-align:center;">Manage Categories</a>
            </div>
        </div>
    </div>

    <section style="margin-top: 2rem;">
        <h2 style="margin-bottom: 1rem; color:#333;">Recent Orders</h2>
        <div class="form-container" style="max-width:100%;">
            <?php if (empty($recent_orders)): ?>
                <div class="alert alert-info">No recent orders.</div>
            <?php else: ?>
                <div style="overflow-x:auto;">
                    <table style="width:100%; border-collapse: collapse;">
                        <thead>
                            <tr>
                                <th style="text-align:left; padding:8px; border-bottom:1px solid #eee;">Order #</th>
                                <th style="text-align:left; padding:8px; border-bottom:1px solid #eee;">Customer</th>
                                <th style="text-align:left; padding:8px; border-bottom:1px solid #eee;">Amount</th>
                                <th style="text-align:left; padding:8px; border-bottom:1px solid #eee;">Status</th>
                                <th style="text-align:left; padding:8px; border-bottom:1px solid #eee;">Date</th>
                                <th style="text-align:left; padding:8px; border-bottom:1px solid #eee;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent_orders as $o): ?>
                                <tr>
                                    <td style="padding:8px; border-bottom:1px solid #f5f5f5;">#<?php echo (int)$o['id']; ?></td>
                                    <td style="padding:8px; border-bottom:1px solid #f5f5f5;"><?php echo htmlspecialchars($o['full_name'] ?: $o['username']); ?></td>
                                    <td style="padding:8px; border-bottom:1px solid #f5f5f5;">$<?php echo number_format((float)$o['total_amount'], 2); ?></td>
                                    <td style="padding:8px; border-bottom:1px solid #f5f5f5; text-transform:capitalize;"><?php echo htmlspecialchars($o['status']); ?></td>
                                    <td style="padding:8px; border-bottom:1px solid #f5f5f5;"><?php echo htmlspecialchars($o['created_at']); ?></td>
                                    <td style="padding:8px; border-bottom:1px solid #f5f5f5;">
                                        <a class="btn-register" href="/computer_shop/admin/order.php?id=<?php echo (int)$o['id']; ?>">View</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </section>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>