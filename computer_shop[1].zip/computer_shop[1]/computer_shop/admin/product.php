<?php
$page_title = "Manage Products";
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../includes/header.php';

$errors = [];
$success = '';

// Load categories for filters and forms
$categories = [];
try {
    $stmt = $pdo->query("SELECT id, name FROM categories WHERE status = 'active' ORDER BY name");
    $categories = $stmt->fetchAll();
} catch (Exception $e) {
    $categories = [];
}

function upload_image($fieldName, $oldFilename = null) {
    if (!isset($_FILES[$fieldName]) || $_FILES[$fieldName]['error'] === UPLOAD_ERR_NO_FILE) {
        return $oldFilename; // No new file uploaded
    }

    $file = $_FILES[$fieldName];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        throw new Exception('Image upload error.');
    }

    $allowed = ['jpg','jpeg','png','gif'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed, true)) {
        throw new Exception('Invalid image type. Allowed: jpg, jpeg, png, gif.');
    }

    if ($file['size'] > 5 * 1024 * 1024) { // 5MB
        throw new Exception('Image too large. Max 5MB.');
    }

    $newName = 'prod_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $destDir = __DIR__ . '/../upload/';
    if (!is_dir($destDir)) {
        mkdir($destDir, 0777, true);
    }
    $destPath = $destDir . $newName;

    if (!move_uploaded_file($file['tmp_name'], $destPath)) {
        throw new Exception('Failed to save image.');
    }

    // Delete old file if exists
    if ($oldFilename) {
        $oldPath = $destDir . $oldFilename;
        if (is_file($oldPath)) {
            @unlink($oldPath);
        }
    }

    return $newName;
}

// Delete product
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id']) && ctype_digit($_GET['id'])) {
    $id = (int)$_GET['id'];
    try {
        // Get current image
        $stmt = $pdo->prepare("SELECT image FROM products WHERE id = ?");
        $stmt->execute([$id]);
        $img = $stmt->fetchColumn();

        $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
        $stmt->execute([$id]);

        if ($stmt->rowCount() > 0 && $img) {
            $path = __DIR__ . '/../upload/' . $img;
            if (is_file($path)) {
                @unlink($path);
            }
        }
        $success = 'Product deleted.';
    } catch (Exception $e) {
        $errors[] = 'Failed to delete product.';
    }
}

// Create or update product
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pid = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = (float)($_POST['price'] ?? 0);
    $category_id = isset($_POST['category_id']) ? (int)$_POST['category_id'] : null;
    $brand = trim($_POST['brand'] ?? '');
    $stock_quantity = (int)($_POST['stock_quantity'] ?? 0);
    $status = in_array(($_POST['status'] ?? 'active'), ['active','inactive'], true) ? $_POST['status'] : 'active';

    if ($name === '' || $price <= 0 || $stock_quantity < 0) {
        $errors[] = 'Please provide valid name, price, and stock quantity.';
    }

    try {
        if (empty($errors)) {
            if ($pid > 0) {
                // Update existing
                // Get old image
                $stmt = $pdo->prepare("SELECT image FROM products WHERE id = ?");
                $stmt->execute([$pid]);
                $oldImg = $stmt->fetchColumn();

                $newImg = $oldImg;
                try {
                    $newImg = upload_image('image', $oldImg);
                } catch (Exception $e) {
                    if ($_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
                        throw $e; // only throw if an upload was attempted
                    }
                }

                $stmt = $pdo->prepare("UPDATE products SET name=?, description=?, price=?, category_id=?, brand=?, stock_quantity=?, image=?, status=? WHERE id=?");
                $stmt->execute([$name, $description, $price, $category_id ?: null, $brand, $stock_quantity, $newImg, $status, $pid]);
                $success = 'Product updated.';
            } else {
                // Create new
                $imgName = null;
                try {
                    $imgName = upload_image('image', null);
                } catch (Exception $e) {
                    // Image optional on create, continue without image if no file chosen
                    if (isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
                        throw $e; // if upload attempted and failed, surface error
                    }
                }

                $stmt = $pdo->prepare("INSERT INTO products (name, description, price, category_id, brand, stock_quantity, image, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$name, $description, $price, $category_id ?: null, $brand, $stock_quantity, $imgName, $status]);
                $success = 'Product created.';
            }
        }
    } catch (Exception $e) {
        $errors[] = $e->getMessage();
    }
}

// Filters and pagination
$search = trim($_GET['search'] ?? '');
$filter_category = trim($_GET['category'] ?? '');
$filter_status = trim($_GET['status'] ?? '');
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$per_page = 15;
$offset = ($page - 1) * $per_page;

$where = [];
$params = [];
if ($search !== '') {
    $where[] = '(p.name LIKE ? OR p.brand LIKE ? OR p.description LIKE ?)';
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}
if ($filter_category !== '' && ctype_digit($filter_category)) {
    $where[] = 'p.category_id = ?';
    $params[] = (int)$filter_category;
}
if ($filter_status !== '' && in_array($filter_status, ['active','inactive'], true)) {
    $where[] = 'p.status = ?';
    $params[] = $filter_status;
}

$where_sql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

// Count
$total = 0;
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM products p $where_sql");
    $stmt->execute($params);
    $total = (int)$stmt->fetchColumn();
} catch (Exception $e) {
    $total = 0;
}
$total_pages = max(1, (int)ceil($total / $per_page));

// Fetch
$products = [];
try {
    $sql = "SELECT p.*, c.name AS category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id $where_sql ORDER BY p.created_at DESC LIMIT $per_page OFFSET $offset";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $products = $stmt->fetchAll();
} catch (Exception $e) {
    $products = [];
}

function selected($a, $b) { return (string)$a === (string)$b ? 'selected' : ''; }
?>

<div class="container">
    <h1 style="color:#333; margin-bottom: 1rem;">Products</h1>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-error">
            <?php foreach ($errors as $err): ?><div><?php echo htmlspecialchars($err); ?></div><?php endforeach; ?>
        </div>
    <?php endif; ?>
    <?php if ($success): ?>
        <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
    <?php endif; ?>

    <!-- Create / Edit Form -->
    <?php $editing = null; if (isset($_GET['action']) && $_GET['action'] === 'edit' && isset($_GET['id']) && ctype_digit($_GET['id'])) {
        $pid = (int)$_GET['id'];
        $stmt = $pdo->prepare('SELECT * FROM products WHERE id = ?');
        $stmt->execute([$pid]);
        $editing = $stmt->fetch();
    } ?>

    <div class="form-container">
        <h2><?php echo $editing ? 'Edit Product' : 'Add New Product'; ?></h2>
        <form method="POST" enctype="multipart/form-data">
            <?php if ($editing): ?>
                <input type="hidden" name="id" value="<?php echo (int)$editing['id']; ?>">
            <?php endif; ?>
            <div class="form-group">
                <label for="name">Name *</label>
                <input type="text" id="name" name="name" required value="<?php echo htmlspecialchars($editing['name'] ?? ''); ?>">
            </div>
            <div class="form-group">
                <label for="description">Description</label>
                <textarea id="description" name="description" rows="4"><?php echo htmlspecialchars($editing['description'] ?? ''); ?></textarea>
            </div>
            <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 1rem;">
                <div class="form-group">
                    <label for="price">Price *</label>
                    <input type="number" step="0.01" id="price" name="price" required value="<?php echo htmlspecialchars($editing['price'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label for="stock_quantity">Stock *</label>
                    <input type="number" id="stock_quantity" name="stock_quantity" min="0" required value="<?php echo htmlspecialchars($editing['stock_quantity'] ?? '0'); ?>">
                </div>
                <div class="form-group">
                    <label for="brand">Brand</label>
                    <input type="text" id="brand" name="brand" value="<?php echo htmlspecialchars($editing['brand'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label for="category_id">Category</label>
                    <select id="category_id" name="category_id">
                        <option value="">-- None --</option>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?php echo (int)$cat['id']; ?>" <?php echo $editing ? selected($editing['category_id'], $cat['id']) : ''; ?>><?php echo htmlspecialchars($cat['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="status">Status</label>
                    <select id="status" name="status">
                        <option value="active" <?php echo $editing ? selected($editing['status'], 'active') : 'selected'; ?>>Active</option>
                        <option value="inactive" <?php echo $editing ? selected($editing['status'], 'inactive') : ''; ?>>Inactive</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label for="image">Image <?php echo $editing && $editing['image'] ? '(upload to replace)' : ''; ?></label>
                <input type="file" id="image" name="image" accept="image/*">
                <?php if ($editing && $editing['image']): ?>
                    <div style="margin-top:0.5rem;">
                        <img src="/computer_shop/upload/<?php echo htmlspecialchars($editing['image']); ?>" alt="" style="width:120px; height:120px; object-fit:cover; border:1px solid #eee; border-radius:6px;">
                    </div>
                <?php endif; ?>
            </div>
            <button type="submit" class="btn-submit"><?php echo $editing ? 'Update' : 'Create'; ?></button>
            <?php if ($editing): ?><a class="btn-register" href="/computer_shop/admin/product.php" style="margin-left:0.5rem;">Cancel</a><?php endif; ?>
        </form>
    </div>

    <!-- Filters -->
    <form method="GET" class="form-container" style="max-width:100%; margin-top:2rem;">
        <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 1rem; align-items:end;">
            <div class="form-group">
                <label for="search">Search</label>
                <input type="text" id="search" name="search" placeholder="Name/Brand/Description" value="<?php echo htmlspecialchars($search); ?>">
            </div>
            <div class="form-group">
                <label for="fcategory">Category</label>
                <select id="fcategory" name="category">
                    <option value="">All</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?php echo (int)$cat['id']; ?>" <?php echo selected($filter_category, $cat['id']); ?>><?php echo htmlspecialchars($cat['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="fstatus">Status</label>
                <select id="fstatus" name="status">
                    <option value="">All</option>
                    <option value="active" <?php echo selected($filter_status, 'active'); ?>>Active</option>
                    <option value="inactive" <?php echo selected($filter_status, 'inactive'); ?>>Inactive</option>
                </select>
            </div>
            <div class="form-group">
                <button type="submit" class="btn-submit">Apply</button>
                <?php if ($search || $filter_category || $filter_status): ?>
                    <a class="btn-register" href="/computer_shop/admin/product.php" style="margin-left:0.5rem;">Clear</a>
                <?php endif; ?>
            </div>
        </div>
    </form>

    <!-- Products Table -->
    <div class="form-container" style="max-width:100%;">
        <?php if (empty($products)): ?>
            <div class="alert alert-info">No products found.</div>
        <?php else: ?>
            <div style="overflow-x:auto;">
                <table style="width:100%; border-collapse: collapse;">
                    <thead>
                        <tr>
                            <th style="text-align:left; padding:8px; border-bottom:1px solid #eee;">Image</th>
                            <th style="text-align:left; padding:8px; border-bottom:1px solid #eee;">Name</th>
                            <th style="text-align:left; padding:8px; border-bottom:1px solid #eee;">Brand</th>
                            <th style="text-align:left; padding:8px; border-bottom:1px solid #eee;">Category</th>
                            <th style="text-align:left; padding:8px; border-bottom:1px solid #eee;">Price</th>
                            <th style="text-align:left; padding:8px; border-bottom:1px solid #eee;">Stock</th>
                            <th style="text-align:left; padding:8px; border-bottom:1px solid #eee;">Status</th>
                            <th style="text-align:left; padding:8px; border-bottom:1px solid #eee;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($products as $p): ?>
                            <tr>
                                <td style="padding:8px; border-bottom:1px solid #f5f5f5;">
                                    <?php if ($p['image']): ?>
                                        <img src="/computer_shop/upload/<?php echo htmlspecialchars($p['image']); ?>" alt="" style="width:50px; height:50px; object-fit:cover; border-radius:4px;">
                                    <?php else: ?>
                                        <span style="color:#aaa;">—</span>
                                    <?php endif; ?>
                                </td>
                                <td style="padding:8px; border-bottom:1px solid #f5f5f5;">
                                    <a href="/computer_shop/product.php?id=<?php echo (int)$p['id']; ?>" target="_blank" style="text-decoration:none; color:#333;">
                                        <?php echo htmlspecialchars($p['name']); ?>
                                    </a>
                                </td>
                                <td style="padding:8px; border-bottom:1px solid #f5f5f5;"><?php echo htmlspecialchars($p['brand'] ?: ''); ?></td>
                                <td style="padding:8px; border-bottom:1px solid #f5f5f5;"><?php echo htmlspecialchars($p['category_name'] ?: '—'); ?></td>
                                <td style="padding:8px; border-bottom:1px solid #f5f5f5;">$<?php echo number_format((float)$p['price'], 2); ?></td>
                                <td style="padding:8px; border-bottom:1px solid #f5f5f5;"><?php echo (int)$p['stock_quantity']; ?></td>
                                <td style="padding:8px; border-bottom:1px solid #f5f5f5; text-transform:capitalize;">
                                    <?php echo htmlspecialchars($p['status']); ?>
                                </td>
                                <td style="padding:8px; border-bottom:1px solid #f5f5f5;">
                                    <a class="btn-register" href="/computer_shop/admin/product.php?action=edit&id=<?php echo (int)$p['id']; ?>">Edit</a>
                                    <a class="btn-logout" style="padding:0.4rem 0.8rem;" href="/computer_shop/admin/product.php?action=delete&id=<?php echo (int)$p['id']; ?>" onclick="return confirm('Delete this product?');">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php if ($total_pages > 1): ?>
                <div style="display:flex; gap:0.5rem; justify-content:center; margin-top:1rem;">
                    <?php if ($page > 1): ?><a class="btn-register" href="/computer_shop/admin/product.php?page=<?php echo $page-1; ?>">Prev</a><?php endif; ?>
                    <span class="btn-login" style="pointer-events:none;">Page <?php echo $page; ?> of <?php echo $total_pages; ?></span>
                    <?php if ($page < $total_pages): ?><a class="btn-register" href="/computer_shop/admin/product.php?page=<?php echo $page+1; ?>">Next</a><?php endif; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>