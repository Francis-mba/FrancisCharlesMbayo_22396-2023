<?php
$page_title = "Manage Orders";
require_once __DIR__ . '/../includes/header.php';
requireAdmin();

$success = '';
$error = '';

// Update order status
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $order_id = (int)($_POST['order_id'] ?? 0);
    $status = trim($_POST['status'] ?? 'pending');
    $allowed = ['pending','processing','shipped','delivered','cancelled'];
    if ($order_id <= 0 || !in_array($status, $allowed, true)) {
        $error = 'Invalid request.';
    } else {
        try {
            $stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?");
            $stmt->execute([$status, $order_id]);
            $success = 'Order status updated.';
        } catch (Exception $e) {
            $error = 'Failed to update order.';
        }
    }
}

// If id provided, show order details
$order = null;
$items = [];
if (isset($_GET['id']) && ctype_digit($_GET['id'])) {
    $id = (int)$_GET['id'];
    try {
        $stmt = $pdo->prepare("SELECT o.*, u.username, u.full_name FROM orders o JOIN users u ON o.user_id = u.id WHERE o.id = ?");
        $stmt->execute([$id]);
        $order = $stmt->fetch();
        
        if ($order) {
            $stmt = $pdo->prepare("SELECT oi.*, p.name FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?");
            $stmt->execute([$id]);
            $items = $stmt->fetchAll();
        }
    } catch (Exception $e) {
        $order = null;
    }
}

// Otherwise list all orders (paginated)
$orders = [];
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$per_page = 15;
$offset = ($page - 1) * $per_page;
$total = 0;

if (!$order) {
    try {
        $total = (int)$pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();
        $stmt = $pdo->query("SELECT o.id, o.total_amount, o.status, o.created_at, u.username, u.full_name
                              FROM orders o JOIN users u ON o.user_id = u.id
                              ORDER BY o.created_at DESC
                              LIMIT $per_page OFFSET $offset");
        $orders = $stmt->fetchAll();
    } catch (Exception $e) {
        $orders = [];
    }
}
?>

<div class="container">
    <h1 style="color:#333; margin-bottom: 1rem;">Orders</h1>

    <?php if ($error): ?><div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
    <?php if ($success): ?><div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div><?php endif; ?>

    <?php if ($order): ?>
        <div class="form-container" style="max-width:100%;">
            <h2>Order #<?php echo (int)$order['id']; ?></h2>
            <p><strong>Customer:</strong> <?php echo htmlspecialchars($order['full_name'] ?: $order['username']); ?></p>
            <p><strong>Status:</strong> <?php echo htmlspecialchars($order['status']); ?></p>
            <p><strong>Created:</strong> <?php echo htmlspecialchars($order['created_at']); ?></p>
            <p><strong>Payment:</strong> <?php echo htmlspecialchars($order['payment_method']); ?></p>
            <p><strong>Shipping Address:</strong><br><pre style="white-space:pre-wrap; background:#f8f9fa; padding:1rem; border-radius:6px;"><?php echo htmlspecialchars($order['shipping_address']); ?></pre></p>

            <h3>Items</h3>
            <div style="overflow-x:auto;">
                <table style="width:100%; border-collapse: collapse;">
                    <thead>
                        <tr>
                            <th style="text-align:left; padding:8px; border-bottom:1px solid #eee;">Product</th>
                            <th style="text-align:left; padding:8px; border-bottom:1px solid #eee;">Qty</th>
                            <th style="text-align:left; padding:8px; border-bottom:1px solid #eee;">Price</th>
                            <th style="text-align:left; padding:8px; border-bottom:1px solid #eee;">Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($items as $it): ?>
                            <tr>
                                <td style="padding:8px; border-bottom:1px solid #f5f5f5;"><?php echo htmlspecialchars($it['name']); ?></td>
                                <td style="padding:8px; border-bottom:1px solid #f5f5f5;"><?php echo (int)$it['quantity']; ?></td>
                                <td style="padding:8px; border-bottom:1px solid #f5f5f5;">$<?php echo number_format((float)$it['price'], 2); ?></td>
                                <td style="padding:8px; border-bottom:1px solid #f5f5f5;">$<?php echo number_format((float)$it['price']*(int)$it['quantity'], 2); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="cart-total" style="text-align:left; margin-top:1rem;">
                <div class="total-amount">Total: $<?php echo number_format((float)$order['total_amount'], 2); ?></div>
            </div>

            <h3 style="margin-top: 1rem;">Update Status</h3>
            <form method="POST">
                <input type="hidden" name="order_id" value="<?php echo (int)$order['id']; ?>">
                <div class="form-group">
                    <select name="status">
                        <?php foreach (['pending','processing','shipped','delivered','cancelled'] as $st): ?>
                            <option value="<?php echo $st; ?>" <?php echo $order['status'] === $st ? 'selected' : ''; ?>><?php echo ucfirst($st); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <button type="submit" class="btn-submit">Save</button>
                <a href="/computer_shop/admin/order.php" class="btn-register" style="margin-left: 0.5rem;">Back to list</a>
            </form>
        </div>
    <?php else: ?>
        <div class="form-container" style="max-width:100%;">
            <?php if (empty($orders)): ?>
                <div class="alert alert-info">No orders found.</div>
            <?php else: ?>
                <div style="overflow-x:auto;">
                    <table style="width:100%; border-collapse: collapse;">
                        <thead>
                            <tr>
                                <th style="text-align:left; padding:8px; border-bottom:1px solid #eee;">Order #</th>
                                <th style="text-align:left; padding:8px; border-bottom:1px solid #eee;">Customer</th>
                                <th style="text-align:left; padding:8px; border-bottom:1px solid #eee;">Amount</th>
                                <th style="text-align:left; padding:8px; border-bottom:1px solid #eee;">Status</th>
                                <th style="text-align:left; padding:8px; border-bottom:1px solid #eee;">Date</th>
                                <th style="text-align:left; padding:8px; border-bottom:1px solid #eee;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($orders as $o): ?>
                                <tr>
                                    <td style="padding:8px; border-bottom:1px solid #f5f5f5;">#<?php echo (int)$o['id']; ?></td>
                                    <td style="padding:8px; border-bottom:1px solid #f5f5f5;"><?php echo htmlspecialchars($o['full_name'] ?: $o['username']); ?></td>
                                    <td style="padding:8px; border-bottom:1px solid #f5f5f5;">$<?php echo number_format((float)$o['total_amount'], 2); ?></td>
                                    <td style="padding:8px; border-bottom:1px solid #f5f5f5; text-transform:capitalize;"><?php echo htmlspecialchars($o['status']); ?></td>
                                    <td style="padding:8px; border-bottom:1px solid #f5f5f5;"><?php echo htmlspecialchars($o['created_at']); ?></td>
                                    <td style="padding:8px; border-bottom:1px solid #f5f5f5;">
                                        <a class="btn-register" href="/computer_shop/admin/order.php?id=<?php echo (int)$o['id']; ?>">View</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php $total_pages = max(1, (int)ceil($total / $per_page)); if ($total_pages > 1): ?>
                    <div style="display:flex; gap:0.5rem; justify-content:center; margin-top:1rem;">
                        <?php if ($page > 1): ?><a class="btn-register" href="/computer_shop/admin/order.php?page=<?php echo $page-1; ?>">Prev</a><?php endif; ?>
                        <span class="btn-login" style="pointer-events:none;">Page <?php echo $page; ?> of <?php echo $total_pages; ?></span>
                        <?php if ($page < $total_pages): ?><a class="btn-register" href="/computer_shop/admin/order.php?page=<?php echo $page+1; ?>">Next</a><?php endif; ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>