<?php
$page_title = "Manage Users";
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../includes/header.php';

$errors = [];
$success = '';

// Role change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'role') {
    $id = (int)($_POST['id'] ?? 0);
    $role = ($_POST['role'] ?? 'customer');
    if ($id <= 0 || !in_array($role, ['customer','admin'], true)) {
        $errors[] = 'Invalid request.';
    } elseif ($id === (int)$_SESSION['user_id']) {
        $errors[] = 'You cannot change your own role.';
    } else {
        try {
            $stmt = $pdo->prepare('UPDATE users SET role = ? WHERE id = ?');
            $stmt->execute([$role, $id]);
            $success = 'Role updated.';
        } catch (Exception $e) {
            $errors[] = 'Failed to update role.';
        }
    }
}

// Delete
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id']) && ctype_digit($_GET['id'])) {
    $id = (int)$_GET['id'];
    if ($id === (int)$_SESSION['user_id']) {
        $errors[] = 'You cannot delete your own account.';
    } else {
        try {
            $stmt = $pdo->prepare('DELETE FROM users WHERE id = ?');
            $stmt->execute([$id]);
            $success = 'User deleted.';
        } catch (Exception $e) {
            $errors[] = 'Failed to delete user.';
        }
    }
}

// List users with pagination
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$per_page = 20;
$offset = ($page - 1) * $per_page;
$total = 0;

$users = [];
try {
    $total = (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
    $stmt = $pdo->query("SELECT id, username, email, full_name, phone, role, created_at FROM users ORDER BY created_at DESC LIMIT $per_page OFFSET $offset");
    $users = $stmt->fetchAll();
} catch (Exception $e) {
    $users = [];
}
$total_pages = max(1, (int)ceil($total / $per_page));
?>

<div class="container">
    <h1 style="color:#333; margin-bottom: 1rem;">Users</h1>

    <?php if (!empty($errors)): ?><div class="alert alert-error"><?php foreach ($errors as $err): ?><div><?php echo htmlspecialchars($err); ?></div><?php endforeach; ?></div><?php endif; ?>
    <?php if ($success): ?><div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div><?php endif; ?>

    <div class="form-container" style="max-width:100%;">
        <?php if (empty($users)): ?>
            <div class="alert alert-info">No users found.</div>
        <?php else: ?>
            <div style="overflow-x:auto;">
                <table style="width:100%; border-collapse: collapse;">
                    <thead>
                        <tr>
                            <th style="text-align:left; padding:8px; border-bottom:1px solid #eee;">Username</th>
                            <th style="text-align:left; padding:8px; border-bottom:1px solid #eee;">Full Name</th>
                            <th style="text-align:left; padding:8px; border-bottom:1px solid #eee;">Email</th>
                            <th style="text-align:left; padding:8px; border-bottom:1px solid #eee;">Phone</th>
                            <th style="text-align:left; padding:8px; border-bottom:1px solid #eee;">Role</th>
                            <th style="text-align:left; padding:8px; border-bottom:1px solid #eee;">Joined</th>
                            <th style="text-align:left; padding:8px; border-bottom:1px solid #eee;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $u): ?>
                            <tr>
                                <td style="padding:8px; border-bottom:1px solid #f5f5f5;"><?php echo htmlspecialchars($u['username']); ?></td>
                                <td style="padding:8px; border-bottom:1px solid #f5f5f5;"><?php echo htmlspecialchars($u['full_name']); ?></td>
                                <td style="padding:8px; border-bottom:1px solid #f5f5f5;"><?php echo htmlspecialchars($u['email']); ?></td>
                                <td style="padding:8px; border-bottom:1px solid #f5f5f5;"><?php echo htmlspecialchars($u['phone']); ?></td>
                                <td style="padding:8px; border-bottom:1px solid #f5f5f5;">
                                    <form method="POST" style="display:inline-flex; gap:0.5rem; align-items:center;">
                                        <input type="hidden" name="action" value="role">
                                        <input type="hidden" name="id" value="<?php echo (int)$u['id']; ?>">
                                        <select name="role">
                                            <option value="customer" <?php echo $u['role']==='customer'?'selected':''; ?>>Customer</option>
                                            <option value="admin" <?php echo $u['role']==='admin'?'selected':''; ?>>Admin</option>
                                        </select>
                                        <button type="submit" class="btn-submit" style="padding:0.4rem 0.8rem;">Update</button>
                                    </form>
                                </td>
                                <td style="padding:8px; border-bottom:1px solid #f5f5f5;"><?php echo htmlspecialchars($u['created_at']); ?></td>
                                <td style="padding:8px; border-bottom:1px solid #f5f5f5;">
                                    <a class="btn-logout" style="padding:0.4rem 0.8rem;" href="/computer_shop/admin/users.php?action=delete&id=<?php echo (int)$u['id']; ?>" onclick="return confirm('Delete this user?');">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php if ($total_pages > 1): ?>
                <div style="display:flex; gap:0.5rem; justify-content:center; margin-top:1rem;">
                    <?php if ($page > 1): ?><a class="btn-register" href="/computer_shop/admin/users.php?page=<?php echo $page-1; ?>">Prev</a><?php endif; ?>
                    <span class="btn-login" style="pointer-events:none;">Page <?php echo $page; ?> of <?php echo $total_pages; ?></span>
                    <?php if ($page < $total_pages): ?><a class="btn-register" href="/computer_shop/admin/users.php?page=<?php echo $page+1; ?>">Next</a><?php endif; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>