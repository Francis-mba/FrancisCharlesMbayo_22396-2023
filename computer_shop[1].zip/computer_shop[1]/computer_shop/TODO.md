# TODO: Change Theme to Computer & Electronic Shop

## Tasks
- [x] Update includes/header.php: Change title, brand name, icon
- [x] Update index.php: Hero text, categories, features
- [x] Update includes/footer.php: Brand name
- [x] Update assets/css/style.css: Change color scheme to blue
- [x] Update about.php: Content to about computer shop
- [x] Update contact.php: Content
- [x] Update admin/dashboard.php: Title
- [x] Update database sample data: Categories and products to tech-related
- [ ] Test the changes
