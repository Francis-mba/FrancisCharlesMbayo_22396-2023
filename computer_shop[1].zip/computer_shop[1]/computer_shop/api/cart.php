<?php
// Cart API endpoint: handles add, update, remove, count actions
header('Content-Type: application/json');

require_once __DIR__ . '/../includes/auth.php';

function respond($data, $status = 200) {
    http_response_code($status);
    echo json_encode($data);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];
$action = isset($_GET['action']) ? $_GET['action'] : null;

// Parse JSON body for POST requests
$input = [];
if ($method === 'POST') {
    $raw = file_get_contents('php://input');
    if ($raw) {
        $parsed = json_decode($raw, true);
        if (json_last_error() === JSON_ERROR_NONE) {
            $input = $parsed;
        }
    }
    // Fallback to form data if JSON body not provided
    if (!$input && !empty($_POST)) {
        $input = $_POST;
    }
    if (isset($input['action'])) {
        $action = $input['action'];
    }
}

// GET: count items in cart
if ($method === 'GET') {
    if ($action === 'count') {
        if (!isLoggedIn()) {
            respond(['success' => true, 'count' => 0]);
        }
        try {
            global $pdo;
            $stmt = $pdo->prepare('SELECT COALESCE(SUM(quantity), 0) AS cnt FROM cart WHERE user_id = ?');
            $stmt->execute([$_SESSION['user_id']]);
            $count = (int)($stmt->fetchColumn() ?: 0);
            respond(['success' => true, 'count' => $count]);
        } catch (Exception $e) {
            respond(['success' => false, 'message' => 'Failed to fetch cart count'], 500);
        }
    }
    respond(['success' => false, 'message' => 'Invalid action'], 400);
}

// POST actions require login
if (!isLoggedIn()) {
    respond(['success' => false, 'message' => 'Please login to manage your cart.'], 401);
}

try {
    global $pdo;

    switch ($action) {
        case 'add': {
            $product_id = isset($input['product_id']) ? (int)$input['product_id'] : 0;
            $quantity = isset($input['quantity']) ? max(1, (int)$input['quantity']) : 1;

            if ($product_id <= 0) {
                respond(['success' => false, 'message' => 'Invalid product'], 400);
            }

            // Verify product
            $stmt = $pdo->prepare("SELECT id, stock_quantity, status FROM products WHERE id = ?");
            $stmt->execute([$product_id]);
            $product = $stmt->fetch();

            if (!$product || $product['status'] !== 'active') {
                respond(['success' => false, 'message' => 'Product not available'], 404);
            }

            if ((int)$product['stock_quantity'] <= 0) {
                respond(['success' => false, 'message' => 'Out of stock'], 400);
            }

            // Check if already in cart
            $stmt = $pdo->prepare("SELECT id, quantity FROM cart WHERE user_id = ? AND product_id = ?");
            $stmt->execute([$_SESSION['user_id'], $product_id]);
            $existing = $stmt->fetch();

            if ($existing) {
                $newQty = min((int)$product['stock_quantity'], (int)$existing['quantity'] + $quantity);
                $stmt = $pdo->prepare("UPDATE cart SET quantity = ? WHERE id = ? AND user_id = ?");
                $stmt->execute([$newQty, $existing['id'], $_SESSION['user_id']]);
            } else {
                $qtyToInsert = min((int)$product['stock_quantity'], $quantity);
                $stmt = $pdo->prepare("INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)");
                $stmt->execute([$_SESSION['user_id'], $product_id, $qtyToInsert]);
            }

            // Return updated count
            $stmt = $pdo->prepare('SELECT COALESCE(SUM(quantity), 0) FROM cart WHERE user_id = ?');
            $stmt->execute([$_SESSION['user_id']]);
            $count = (int)($stmt->fetchColumn() ?: 0);

            respond(['success' => true, 'message' => 'Added to cart', 'count' => $count]);
        }
        case 'update': {
            $cart_id = isset($input['cart_id']) ? (int)$input['cart_id'] : 0;
            $quantity = isset($input['quantity']) ? (int)$input['quantity'] : 0;

            if ($cart_id <= 0) {
                respond(['success' => false, 'message' => 'Invalid cart item'], 400);
            }

            if ($quantity <= 0) {
                // Remove if quantity is zero or negative
                $stmt = $pdo->prepare("DELETE FROM cart WHERE id = ? AND user_id = ?");
                $stmt->execute([$cart_id, $_SESSION['user_id']]);
                respond(['success' => true, 'message' => 'Item removed']);
            }

            // Join to get product stock
            $stmt = $pdo->prepare("SELECT c.id, c.product_id, p.stock_quantity FROM cart c JOIN products p ON c.product_id = p.id WHERE c.id = ? AND c.user_id = ?");
            $stmt->execute([$cart_id, $_SESSION['user_id']]);
            $row = $stmt->fetch();
            if (!$row) {
                respond(['success' => false, 'message' => 'Cart item not found'], 404);
            }

            $newQty = min((int)$row['stock_quantity'], max(1, $quantity));
            $stmt = $pdo->prepare("UPDATE cart SET quantity = ? WHERE id = ? AND user_id = ?");
            $stmt->execute([$newQty, $cart_id, $_SESSION['user_id']]);
            respond(['success' => true, 'message' => 'Quantity updated']);
        }
        case 'remove': {
            $cart_id = isset($input['cart_id']) ? (int)$input['cart_id'] : 0;
            if ($cart_id <= 0) {
                respond(['success' => false, 'message' => 'Invalid cart item'], 400);
            }
            $stmt = $pdo->prepare("DELETE FROM cart WHERE id = ? AND user_id = ?");
            $stmt->execute([$cart_id, $_SESSION['user_id']]);
            respond(['success' => true, 'message' => 'Item removed']);
        }
        default:
            respond(['success' => false, 'message' => 'Invalid action'], 400);
    }
} catch (Exception $e) {
    respond(['success' => false, 'message' => 'Server error'], 500);
}
