    </main>
    
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>Computer & Electronic Shop</h3>
                    <p>Your one-stop destination for computers and electronic products.</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-facebook"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                    </div>
                </div>
                
                <div class="footer-section">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="/computer_shop/index.php">Home</a></li>
                        <li><a href="/computer_shop/shop.php">Shop</a></li>
                        <li><a href="/computer_shop/about.php">About Us</a></li>
                        <li><a href="/computer_shop/contact.php">Contact</a></li>
                    </ul>
                </div>
                
                <div class="footer-section">
                    <h4>Categories</h4>
                    <ul>
                        <li><a href="/computer_shop/shop.php?category=laptops">Laptops</a></li>
                        <li><a href="/computer_shop/shop.php?category=desktops">Desktops</a></li>
                        <li><a href="/computer_shop/shop.php?category=accessories">Accessories</a></li>
                        <li><a href="/computer_shop/shop.php?category=components">Components</a></li>
                    </ul>
                </div>
                
                <div class="footer-section">
                    <h4>Contact Info</h4>
                    <p><i class="fas fa-map-marker-alt"></i> 123 Tech Street, City</p>
                    <p><i class="fas fa-phone"></i> +250 799 354 618</p>
                    <p><i class="fas fa-envelope"></i> info@computershop.com</p>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; 2024 Computer & Electronic Shop. All rights reserved.</p>
            </div>
        </div>
    </footer>
    
    <script src="/computer_shop/assets/js/script.js"></script>
</body>
</html>