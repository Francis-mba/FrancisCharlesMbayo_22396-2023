<?php
require_once __DIR__ . '/auth.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title . ' - ' : ''; ?>Computer & Electronic Shop</title>
    <link rel="stylesheet" href="/computer_shop/assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="nav-brand">
                <a href="/computer_shop/index.php">
                    <i class="fas fa-laptop"></i>
                    Computer & Electronic Shop
                </a>
            </div>
            
            <nav class="nav-menu">
                <ul>
                    <li><a href="/computer_shop/index.php">Home</a></li>
                    <li><a href="/computer_shop/shop.php">Shop</a></li>
                    <li><a href="/computer_shop/about.php">About</a></li>
                    <li><a href="/computer_shop/contact.php">Contact</a></li>
                </ul>
            </nav>
            
            <div class="nav-actions">
                <?php if (isLoggedIn()): ?>
                    <div class="user-menu">
                        <span>Welcome, <?php echo htmlspecialchars($_SESSION['full_name']); ?></span>
                        <?php if (isAdmin()): ?>
                            <a href="/computer_shop/admin/dashboard.php" class="btn-admin">
                                <i class="fas fa-cog"></i> Admin
                            </a>
                        <?php endif; ?>
                        <a href="/computer_shop/cart.php" class="cart-link">
                            <i class="fas fa-shopping-cart"></i>
                            <span class="cart-count" id="cart-count">0</span>
                        </a>
                        <a href="/computer_shop/logout.php" class="btn-logout">Logout</a>
                    </div>
                <?php else: ?>
                    <div class="auth-links">
                        <a href="/computer_shop/login.php" class="btn-login">Login</a>
                        <a href="/computer_shop/register.php" class="btn-register">Register</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </header>
    
    <main class="main-content">