<?php
require_once 'includes/auth.php';

// Logout user
logoutUser();
?>